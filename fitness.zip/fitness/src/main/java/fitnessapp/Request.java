package fitnessapp;

public class Request {
	private String partname;

	public String getPartname() {
		return partname;
	}

	public void setPartname(String partname) {
		this.partname = partname;
	}
}
