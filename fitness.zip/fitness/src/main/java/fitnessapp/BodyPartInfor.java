package fitnessapp;

public class BodyPartInfor {
	private String exercisename;
	private String partname;
	public String getExercisename() {
		return exercisename;
	}
	public void setExercisename(String exercisename) {
		this.exercisename = exercisename;
	}
	public String getPartname() {
		return partname;
	}
	public void setPartname(String partname) {
		this.partname = partname;
	}

}
